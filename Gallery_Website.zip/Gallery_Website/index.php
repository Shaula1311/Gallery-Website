<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <title>Slide Show</title>
        <link rel="stylesheet" href="style.css">
        <link rel="script" href="slideshow.js">
    </head>

    <body>
        <div class="container">
            <div class="arrow l" onclick="prev()">
                <img src="images/L.png" alt="left arrow">
            </div>

            <div class="slide slide1">
                <div class="caption">
                    <h3>Kazakh Steppe</h3>
                    <p>Great Endless Steppe!</p>
                </div>
            </div>

            <div class="slide slide2">
                <div class="caption">
                    <h3>Big Almaty Lake</h3>
                    <p>Blue Lake Hidden In The Mountains</p>
                </div>
            </div>

            <div class="slide slide3">
                <div class="caption">
                    <h3>Singing Dune</h3>
                    <p>Amazing Singing Sands</p>
                </div>
            </div>

            <div class="slide slide4">
                <div class="caption">
                    <h3>Lake Kaindy</h3>
                    <p>Sunken Forest</p>
                </div>
            </div>

            <div class="arrow r" onclick="next()">
                <img src="images/R.png" alt="right arrow">
            </div>

        </div>

        <script>
            let slide = document.querySelectorAll('.slide');
        var current = 0;

        function cls(){
            for(let i = 0; i < slide.length; i++){
                  slide[i].style.display = 'none';
            }
        }

        function next(){
            cls();
            if(current === slide.length-1) current = -1;
            current++;

            slide[current].style.display = 'block';
            slide[current].style.opacity = 0.4;

            var x = 0.4;
            var intX = setInterval(function(){
                x+=0.1;
                slide[current].style.opacity = x;
                if(x >= 1) {
                    clearInterval(intX);
                    x = 0.4;
                }
            }, 100);

        }

        function prev(){
            cls();
            if(current === 0) current = slide.length;
            current--;

            slide[current].style.display = 'block';
            slide[current].style.opacity = 0.4;

            var x = 0.4;
            var intX = setInterval(function(){
                x+=0.1;
                slide[current].style.opacity = x;
                if(x >= 1) {
                    clearInterval(intX);
                    x = 0.4;
                }
            }, 100);

        }

        function start(){
            cls();
            slide[current].style.display = 'block';
        }
        start();
        </script>
    </body>


</html>